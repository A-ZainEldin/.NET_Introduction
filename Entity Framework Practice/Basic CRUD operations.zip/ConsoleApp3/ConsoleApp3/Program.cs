﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var context = new CustomerContext();
            var customers = new List<Customer>{
                new Customer { Name = "Alice Johnson", Age = 28, MoneySpent = 1500, PointsSpent = 200, PointsCollected = 220 },
                new Customer { Name = "Bob Smith", Age = 35, MoneySpent = 3200, PointsSpent = 450, PointsCollected = 500 },
                new Customer { Name = "Charlie Brown", Age = 42, MoneySpent = 2700, PointsSpent = 300, PointsCollected = 350 },
                new Customer { Name = "Diana Prince", Age = 31, MoneySpent = 1200, PointsSpent = 150, PointsCollected = 180 },
                new Customer { Name = "Edward Norton", Age = 40, MoneySpent = 2000, PointsSpent = 250, PointsCollected = 275 },
                new Customer { Name = "Fiona Apple", Age = 29, MoneySpent = 800, PointsSpent = 100, PointsCollected = 120 },
                new Customer { Name = "George Lucas", Age = 50, MoneySpent = 4000, PointsSpent = 600, PointsCollected = 620 },
                new Customer { Name = "Hannah Montana", Age = 22, MoneySpent = 600, PointsSpent = 80, PointsCollected = 90 },
                new Customer { Name = "Ivy League", Age = 33, MoneySpent = 1500, PointsSpent = 200, PointsCollected = 230 },
                new Customer { Name = "Jack Sparrow", Age = 45, MoneySpent = 3500, PointsSpent = 500, PointsCollected = 530 }
            };
            var customerX = context.Customers.ToList();


            ////clear DB
            //foreach (var customer in customerX)
            //{
            //    context.Customers.Remove(customer);
            //}
            //context.SaveChanges();

            //Populates DB
            foreach (var customer in customers)
            {
                context.Customers.Add(customer);
            }
            context.SaveChanges();

            Console.WriteLine("\nThe Intial Data:");
            foreach (var customer in context.Customers.ToList())
            {
                Console.WriteLine($"ID: {customer.CustomerId}, Name: {customer.Name}, Age: {customer.Age}, MoneySpent: {customer.MoneySpent}, PointsSpent: {customer.PointsSpent}, PointsCollected: {customer.PointsCollected}");
            }
            var cust = context.Customers.FirstOrDefault(a => a.CustomerId == 1);
            if (cust != null)
            {
                context.Customers.Remove(cust);
            }
            context.SaveChanges();

            Console.WriteLine("\nAfter Removal Of ID 1");
            foreach (var customer in context.Customers.ToList())
            {
                Console.WriteLine($"ID: {customer.CustomerId}, Name: {customer.Name}, Age: {customer.Age}, MoneySpent: {customer.MoneySpent}, PointsSpent: {customer.PointsSpent}, PointsCollected: {customer.PointsCollected}");
            }

        }
    }
}
